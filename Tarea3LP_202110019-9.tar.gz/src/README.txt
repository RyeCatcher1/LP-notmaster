Mateo Hidalgo Gudenschwager
202110019-9


estoy compilando con el compilador integrado de VS Code.



para correr el programa se debe ejecutar por consola
make
make run

para limpiar se debe hacer
make clean

y de ahi se puede volver a correr.

Para guardar algo con git hago lo siguiente:
- voy a la parte de source control de vs Code
- le pongo commit
- escribo alguna frase (por ejemplo "ya listos todos los enemigos" (sin comillas))
- le pongo sincronizar



