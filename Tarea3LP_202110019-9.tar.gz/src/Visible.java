public interface Visible {
    char getRepresentacion();
}
